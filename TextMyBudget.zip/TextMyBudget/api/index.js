// Export the Express app for Vercel serverless deployment
module.exports = require('../dist/index.js');